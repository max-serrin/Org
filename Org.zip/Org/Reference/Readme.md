# Reference
Reference is a floating reference window for artists. Drag and drop an image or directory. A customizable built-in timer and random image selection allows for timed drawings such as gesture or figure drawing.
