﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyExtensions;

namespace Org
{
    public partial class Org : Form
    {
        private Images images;
        private Traverser<FileInfo> traverser;
        private Mode mode;

        private ContextMenu pictureBoxContextMenu;
        private ContextMenu treeViewContextMenu;
        private TreeNode favorites;
        private FullScreen fullScreen;
        private Settings settings;

        private Dictionary<Keys, string> hotkeys;
        private Regex scriptRegex;


        private enum Mode
        {
            Browse,
            Organize,
            Randomize
        };

        public Org(string directory)
        {
            // Initialization
            InitializeComponent();

            // Hotkeys Setup
            hotkeys = new Dictionary<Keys, string>();
            foreach (Keys key in DataExtensions.GetCommonKeysAndButtons())
            {
                hotkeys.Add(key, "");
            }
            hotkeys[Keys.Left] = "previous";
            hotkeys[Keys.Right] = "next";
            hotkeys[Keys.A] = "move, %current_full%, %current_directory%\\best\\%current_name%";
            scriptRegex = new Regex(@"(?<="")\w[\w\s]*(?="")|\w+|""[\w\s]*""");

            pictureBox.MouseWheel += PictureBox_MouseWheel;

            // PictureBox Context Menu Setup
            pictureBoxContextMenu = new ContextMenu();
            pictureBoxContextMenu.MenuItems.Add("Randomize", pictureBoxContextMenu_Randomize_onClick);
            pictureBoxContextMenu.MenuItems.Add("Reference", pictureBoxContextMenu_Reference_onClick);
            pictureBox.ContextMenu = pictureBoxContextMenu;

            // TreeView Context Menu Setup
            treeViewContextMenu = new ContextMenu();
            treeViewContextMenu.MenuItems.Add("Add to Favorites", treeViewContextMenu_AddToFavorites_onClick);
            treeViewContextMenu.MenuItems.Add("Remove from Favorites", treeViewContextMenu_RemoveFromFavorites_onClick);
            treeViewContextMenu.MenuItems.Add("Randomize", treeViewContextMenu_Randomize_onClick);
            folderBrowser.ContextMenu = treeViewContextMenu;

            //Dialogs
            fullScreen = new FullScreen(pictureBox, this);
            settings = new Settings();

            // Mode Setup
            mode = Mode.Browse;
            browseToolStripMenuItem.Checked = true;

            // Load Images
            images = new Images(directory);

            // TreeView Setup
            folderBrowser.Nodes.Clear();
            favorites = new TreeNode("Favorites");
            favorites.Tag = "";
            folderBrowser.Nodes.Add(favorites);
            ListDirectory(folderBrowser);
        }

        private void treeViewContextMenu_RemoveFromFavorites_onClick(object sender, EventArgs e)
        {
            if (folderBrowser.SelectedNode.Tag.Exists())
            {   // Selected node is part of the favorites node
                if (folderBrowser.SelectedNode.Parent.Exists())
                {   // Selected node is not the favorite node itself
                    favorites.Nodes.Remove(folderBrowser.SelectedNode);
                }
            }
            else
            {
                // Figure out which favorite node matches the selected node and remove it
                foreach (TreeNode node in favorites.Nodes)
                {
                    if (node.Tag.Equals(folderBrowser.SelectedNode.FullPath))
                    {
                        favorites.Nodes.Remove(node);
                        break;
                    }
                }
            }
        }

        private void treeViewContextMenu_AddToFavorites_onClick(object sender, EventArgs e)
        {
            TreeNode favorite = new TreeNode(folderBrowser.SelectedNode.Text);
            favorite.Tag = folderBrowser.SelectedNode.FullPath;
            favorites.Nodes.Add(favorite);
        }

        private void hotkeyScriptParser(string script)
        {
            foreach (string line in Regex.Split(script, "\r\n"))
            {
                string[] scriptSplit = Regex.Split(line, ", ");
                if (scriptSplit.Length > 2)
                {
                    string scriptEdit = scriptSplit[1] + "|" + scriptSplit[2];
                    scriptEdit = Regex.Replace(scriptEdit, "%current_full%", traverser.GetCurrent().FullName);
                    scriptEdit = Regex.Replace(scriptEdit, "%current_name%", traverser.GetCurrent().Name);
                    scriptEdit = Regex.Replace(scriptEdit, "%current_directory%", traverser.GetCurrent().DirectoryName);
                    string[] scriptResplit = scriptEdit.Split('|');
                    scriptSplit[1] = scriptResplit[0];
                    scriptSplit[2] = scriptResplit[1];

                    string directoryPart = scriptSplit[2].Substring(0, scriptSplit[2].LastIndexOf('\\'));
                    if (!Directory.Exists(directoryPart))
                    {
                        Directory.CreateDirectory(directoryPart);
                    }
                }
                

                switch (scriptSplit[0])
                {
                    case "move":
                        File.Move(scriptSplit[1], scriptSplit[2]);
                        break;
                    case "next":
                        Next();
                        break;
                    case "previous":
                        Previous();
                        break;
                    default:
                        break;
                }
            }
        }

        private void pictureBoxContextMenu_Reference_onClick(object sender, EventArgs e)
        {
            new Reference.Reference(traverser.GetCurrent()).Show();
        }

        private void treeViewContextMenu_Randomize_onClick(object sender, EventArgs e)
        {
            // Set randomize mode
            setMode(Mode.Randomize, randomizeToolStripMenuItem);
            // Simluate a left click on the node
            folderBrowser_MouseClick(sender, new MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0));
        }

        private void pictureBoxContextMenu_Randomize_onClick(object sender, EventArgs e)
        {
            randomizeToolStripMenuItem_Click(sender, e);
        }

        public void PictureBox_MouseWheel(object sender, MouseEventArgs e)
        {
            if (e.Delta > 0)
            {
                Next();
            }
            else if (e.Delta < 0)
            {
                Previous();
            }
        }

        private void ListDirectory(TreeView treeView)
        {
            foreach (DriveInfo driveInfo in DriveInfo.GetDrives())
            {
                treeView.Nodes.Add(new TreeNode(driveInfo.Name));
            }
            foreach (TreeNode treeNode in treeView.Nodes)
            {
                CreateDirectoryNode(treeNode);
            }
        }

        private static void CreateDirectoryNode(TreeNode directoryNode)
        {
            directoryNode.Nodes.Clear();
            try
            {
                foreach (var directory in new DirectoryInfo(directoryNode.FullPath).GetDirectories())
                {
                    directoryNode.Nodes.Add(new TreeNode(directory.Name));
                }
            }
            catch
            {
                return;
            }
        }

        private void folderBrowser_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            // Set the selected node (right clicks don't do this automatically)
            ((TreeView)sender).SelectedNode = e.Node;
            
            // If we left clicked, load the directory
            if (e.Button.Equals(MouseButtons.Left))
            {
                if (e.Node.Tag.Exists())
                {   // Exists in the favorite node
                    if (e.Node.Parent.Exists())
                    {   // Is not the favorite node itself
                        images = new Images((string)e.Node.Tag);
                    }
                }
                else
                {   // Is a directory
                    images = new Images(e.Node.FullPath);
                }
                LoadDirectory();
            }

        }

        private void LoadDirectory()
        {
            if (mode == Mode.Randomize)
            {
                traverser = (Traverser<FileInfo>)images.GetRandomizedTraverser();
            }
            else
            {
                traverser = (Traverser<FileInfo>)images.GetTraverser();
            }

            try
            {
                pictureBox.ImageLocation = traverser.GetCurrent().FullName;
            }
            catch (NullReferenceException ex)
            {
                pictureBox.ImageLocation = "";
            }
            toolStripStatusLabel1.Text = traverser.Count().ToString() + " items";
        }

        private void folderBrowser_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            foreach (TreeNode node in e.Node.Nodes)
            {
                CreateDirectoryNode(node);
            }
        }

        private void browseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            setMode(Mode.Browse, browseToolStripMenuItem);
            LoadDirectory();
        }

        private void organizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            setMode(Mode.Organize, randomizeToolStripMenuItem);
            LoadDirectory();
        }

        private void randomizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            setMode(Mode.Randomize, randomizeToolStripMenuItem);
            LoadDirectory();
        }

        private void setMode(Mode _mode, ToolStripMenuItem menuItem)
        {
            UncheckMode();
            mode = _mode;
            menuItem.Checked = true;
        }

        private void UncheckMode()
        {
            foreach (ToolStripMenuItem item in modeToolStripMenuItem.DropDown.Items)
            {
                item.Checked = false;
            }
        }

        private void Org_KeyDown(object sender, KeyEventArgs e)
        {
            string script = hotkeys[e.KeyCode];
            if (script != "")
            {
                hotkeyScriptParser(script);
                e.Handled = true;
            }
            /*
            switch (e.KeyCode)
            {
                case Keys.Left:
                    Previous();
                    e.Handled = true;
                    break;
                case Keys.Right:
                    Next();
                    e.Handled = true;
                    break;
                default:
                    break;
            }
            */
        }

        private void Previous()
        {
            try
            {
                pictureBox.ImageLocation = traverser.MovePrevious().FullName;
            }
            catch (NullReferenceException ex)
            {
                pictureBox.ImageLocation = "";
            }
        }

        private void Next()
        {
            try
            {
                pictureBox.ImageLocation = traverser.MoveNext().FullName;
            }
            catch (NullReferenceException ex)
            {
                pictureBox.ImageLocation = "";
            }
        }

        private void folderBrowser_MouseClick(object sender, MouseEventArgs e)
        {
            CheckXButtons(e);

        }

        private void CheckXButtons(MouseEventArgs e)
        {
            if (e.Button.Equals(MouseButtons.XButton1))
            {
                Next();
            }
            else if (e.Button.Equals(MouseButtons.XButton2))
            {
                Previous();
            }
        }

        private void Org_MouseClick(object sender, MouseEventArgs e)
        {
            CheckXButtons(e);
        }

        public void pictureBox_MouseClick(object sender, MouseEventArgs e)
        {
            CheckXButtons(e);
        }

        private void pictureBox_MouseEnter(object sender, EventArgs e)
        {
            if (!pictureBox.Focused && !settings.Visible)
            {
                pictureBox.Focus();
            }
        }

        private void pictureBox_DoubleClick(object sender, MouseEventArgs e)
        {
            if (e.Button.Equals(MouseButtons.Left))
            {
                fullScreen.UpdatePictureBox();
                fullScreen.Show();
            }
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            settings.Show();
        }
    }
}
