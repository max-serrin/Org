﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Org
{
    public partial class Org : Form
    {
        public Org()
        {
            InitializeComponent();
            Images images = new Images();
            IEnumerator imagesEnumerator = images.GetEnumerator();
            imagesEnumerator.
        }
    }
}
