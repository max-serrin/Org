﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyExtensions;

namespace Org
{
    public partial class Settings : Form
    {

        private enum SettingsType
        {
            General,
            Hotkeys
        };

        CheckBox checkbox;

        public Settings()
        {
            InitializeComponent();

            settingsList.Items.Clear();
            foreach (SettingsType settingsType in Enum.GetValues(typeof(SettingsType)))
            {
                settingsList.Items.Add(settingsType);
            }
            settingsList.SelectedIndex = 0;
        }

        private void Settings_FormClosing(object sender, FormClosingEventArgs e)
        {
            Hide();
            e.Cancel = true;
        }

        private void settingsList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (settingsList.SelectedItem.Equals(SettingsType.General))
            {
                SettingsLayoutPanelInitialize_GeneralSettings();
            }
            if (settingsList.SelectedItem.Equals(SettingsType.Hotkeys))
            {
                SettingsLayoutPanelInitialize_HotkeysSettings();
            }
        }

        private void SettingsLayoutPanelInitialize_HotkeysSettings()
        {
            settingsLayoutPanel.Controls.Clear();
            ComboBox hotkeys = new ComboBox();
            foreach (Keys key in DataExtensions.GetCommonKeysAndButtons())
                hotkeys.Items.Add(key.ToCommonString());
            settingsLayoutPanel.Controls.Add(hotkeys);
        }

        private void SettingsLayoutPanelInitialize_GeneralSettings()
        {
            settingsLayoutPanel.Controls.Clear();
            settingsLayoutPanel.Controls.Add(checkbox = new CheckBox() { Text = "General"});
        }
    }
}
