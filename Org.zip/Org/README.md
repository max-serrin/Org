# Org
Personal programs for file organization and other file management.

## BrowseByRating

## ConsoleTest

## DL

## DrawaD

## GetRandom

## GetRandomFromFile

## GetRandomImage

## JJDL

## MoveFiles

## Org+

## Org

## Orgx4

## Random

## RandomImage

## RandomTest

## Rating

## RatingCalc

## Reference
Reference is a floating reference window for artists. Drag and drop an image or directory. A customizable built-in timer and random image selection allows for timed drawings such as gesture or figure drawing.

## Tourn

## Tourny

## WIGC

## WebApplication1

## WindowsFormsApplication1
