﻿namespace RatingCalc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.bFace = new System.Windows.Forms.GroupBox();
            this.sFace = new System.Windows.Forms.TrackBar();
            this.bHair = new System.Windows.Forms.GroupBox();
            this.sHair = new System.Windows.Forms.TrackBar();
            this.bChest = new System.Windows.Forms.GroupBox();
            this.sChest = new System.Windows.Forms.TrackBar();
            this.bStomach = new System.Windows.Forms.GroupBox();
            this.sStomach = new System.Windows.Forms.TrackBar();
            this.bPelvis = new System.Windows.Forms.GroupBox();
            this.sPelvis = new System.Windows.Forms.TrackBar();
            this.bArms = new System.Windows.Forms.GroupBox();
            this.sArms = new System.Windows.Forms.TrackBar();
            this.bLegs = new System.Windows.Forms.GroupBox();
            this.sLegs = new System.Windows.Forms.TrackBar();
            this.bClothes = new System.Windows.Forms.GroupBox();
            this.sClothes = new System.Windows.Forms.TrackBar();
            this.bPose = new System.Windows.Forms.GroupBox();
            this.sPose = new System.Windows.Forms.TrackBar();
            this.bQuality = new System.Windows.Forms.GroupBox();
            this.sQuality = new System.Windows.Forms.TrackBar();
            this.bBackground = new System.Windows.Forms.GroupBox();
            this.sBackground = new System.Windows.Forms.TrackBar();
            this.bOther = new System.Windows.Forms.GroupBox();
            this.sOther = new System.Windows.Forms.TrackBar();
            this.bFinish = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.tbRating = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openCollectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.skipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goToIndexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.removeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lIndex = new System.Windows.Forms.ToolStripStatusLabel();
            this.lFilename = new System.Windows.Forms.ToolStripStatusLabel();
            this.bUndo = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.bFace.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFace)).BeginInit();
            this.bHair.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sHair)).BeginInit();
            this.bChest.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sChest)).BeginInit();
            this.bStomach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sStomach)).BeginInit();
            this.bPelvis.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sPelvis)).BeginInit();
            this.bArms.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sArms)).BeginInit();
            this.bLegs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sLegs)).BeginInit();
            this.bClothes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sClothes)).BeginInit();
            this.bPose.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sPose)).BeginInit();
            this.bQuality.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sQuality)).BeginInit();
            this.bBackground.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sBackground)).BeginInit();
            this.bOther.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sOther)).BeginInit();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 24);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 631F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1004, 631);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(747, 625);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.flowLayoutPanel1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(756, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(245, 625);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.bFace);
            this.flowLayoutPanel1.Controls.Add(this.bHair);
            this.flowLayoutPanel1.Controls.Add(this.bChest);
            this.flowLayoutPanel1.Controls.Add(this.bStomach);
            this.flowLayoutPanel1.Controls.Add(this.bPelvis);
            this.flowLayoutPanel1.Controls.Add(this.bArms);
            this.flowLayoutPanel1.Controls.Add(this.bLegs);
            this.flowLayoutPanel1.Controls.Add(this.bClothes);
            this.flowLayoutPanel1.Controls.Add(this.bPose);
            this.flowLayoutPanel1.Controls.Add(this.bQuality);
            this.flowLayoutPanel1.Controls.Add(this.bBackground);
            this.flowLayoutPanel1.Controls.Add(this.bOther);
            this.flowLayoutPanel1.Controls.Add(this.bFinish);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel1.MaximumSize = new System.Drawing.Size(1000, 1000);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(239, 306);
            this.flowLayoutPanel1.TabIndex = 2;
            // 
            // bFace
            // 
            this.bFace.Controls.Add(this.sFace);
            this.bFace.Location = new System.Drawing.Point(3, 3);
            this.bFace.Name = "bFace";
            this.bFace.Size = new System.Drawing.Size(108, 72);
            this.bFace.TabIndex = 2;
            this.bFace.TabStop = false;
            this.bFace.Text = "Face";
            // 
            // sFace
            // 
            this.sFace.Location = new System.Drawing.Point(7, 20);
            this.sFace.Maximum = 5;
            this.sFace.Name = "sFace";
            this.sFace.Size = new System.Drawing.Size(95, 45);
            this.sFace.TabIndex = 0;
            // 
            // bHair
            // 
            this.bHair.Controls.Add(this.sHair);
            this.bHair.Location = new System.Drawing.Point(117, 3);
            this.bHair.Name = "bHair";
            this.bHair.Size = new System.Drawing.Size(108, 72);
            this.bHair.TabIndex = 3;
            this.bHair.TabStop = false;
            this.bHair.Text = "Hair";
            // 
            // sHair
            // 
            this.sHair.Location = new System.Drawing.Point(7, 20);
            this.sHair.Maximum = 5;
            this.sHair.Name = "sHair";
            this.sHair.Size = new System.Drawing.Size(95, 45);
            this.sHair.TabIndex = 0;
            // 
            // bChest
            // 
            this.bChest.Controls.Add(this.sChest);
            this.bChest.Location = new System.Drawing.Point(3, 81);
            this.bChest.Name = "bChest";
            this.bChest.Size = new System.Drawing.Size(108, 72);
            this.bChest.TabIndex = 4;
            this.bChest.TabStop = false;
            this.bChest.Text = "Chest";
            // 
            // sChest
            // 
            this.sChest.Location = new System.Drawing.Point(7, 20);
            this.sChest.Maximum = 5;
            this.sChest.Name = "sChest";
            this.sChest.Size = new System.Drawing.Size(95, 45);
            this.sChest.TabIndex = 0;
            // 
            // bStomach
            // 
            this.bStomach.Controls.Add(this.sStomach);
            this.bStomach.Location = new System.Drawing.Point(117, 81);
            this.bStomach.Name = "bStomach";
            this.bStomach.Size = new System.Drawing.Size(108, 72);
            this.bStomach.TabIndex = 5;
            this.bStomach.TabStop = false;
            this.bStomach.Text = "Stomach";
            // 
            // sStomach
            // 
            this.sStomach.Location = new System.Drawing.Point(7, 20);
            this.sStomach.Maximum = 5;
            this.sStomach.Name = "sStomach";
            this.sStomach.Size = new System.Drawing.Size(95, 45);
            this.sStomach.TabIndex = 0;
            // 
            // bPelvis
            // 
            this.bPelvis.Controls.Add(this.sPelvis);
            this.bPelvis.Location = new System.Drawing.Point(3, 159);
            this.bPelvis.Name = "bPelvis";
            this.bPelvis.Size = new System.Drawing.Size(108, 72);
            this.bPelvis.TabIndex = 6;
            this.bPelvis.TabStop = false;
            this.bPelvis.Text = "Pelivs";
            // 
            // sPelvis
            // 
            this.sPelvis.Location = new System.Drawing.Point(7, 20);
            this.sPelvis.Maximum = 5;
            this.sPelvis.Name = "sPelvis";
            this.sPelvis.Size = new System.Drawing.Size(95, 45);
            this.sPelvis.TabIndex = 0;
            // 
            // bArms
            // 
            this.bArms.Controls.Add(this.sArms);
            this.bArms.Location = new System.Drawing.Point(117, 159);
            this.bArms.Name = "bArms";
            this.bArms.Size = new System.Drawing.Size(108, 72);
            this.bArms.TabIndex = 7;
            this.bArms.TabStop = false;
            this.bArms.Text = "Arms";
            // 
            // sArms
            // 
            this.sArms.Location = new System.Drawing.Point(7, 20);
            this.sArms.Maximum = 5;
            this.sArms.Name = "sArms";
            this.sArms.Size = new System.Drawing.Size(95, 45);
            this.sArms.TabIndex = 0;
            // 
            // bLegs
            // 
            this.bLegs.Controls.Add(this.sLegs);
            this.bLegs.Location = new System.Drawing.Point(3, 237);
            this.bLegs.Name = "bLegs";
            this.bLegs.Size = new System.Drawing.Size(108, 72);
            this.bLegs.TabIndex = 8;
            this.bLegs.TabStop = false;
            this.bLegs.Text = "Legs";
            // 
            // sLegs
            // 
            this.sLegs.Location = new System.Drawing.Point(7, 20);
            this.sLegs.Maximum = 5;
            this.sLegs.Name = "sLegs";
            this.sLegs.Size = new System.Drawing.Size(95, 45);
            this.sLegs.TabIndex = 0;
            // 
            // bClothes
            // 
            this.bClothes.Controls.Add(this.sClothes);
            this.bClothes.Location = new System.Drawing.Point(117, 237);
            this.bClothes.Name = "bClothes";
            this.bClothes.Size = new System.Drawing.Size(108, 72);
            this.bClothes.TabIndex = 9;
            this.bClothes.TabStop = false;
            this.bClothes.Text = "Clothes";
            // 
            // sClothes
            // 
            this.sClothes.Location = new System.Drawing.Point(7, 20);
            this.sClothes.Maximum = 5;
            this.sClothes.Name = "sClothes";
            this.sClothes.Size = new System.Drawing.Size(95, 45);
            this.sClothes.TabIndex = 0;
            // 
            // bPose
            // 
            this.bPose.Controls.Add(this.sPose);
            this.bPose.Location = new System.Drawing.Point(3, 315);
            this.bPose.Name = "bPose";
            this.bPose.Size = new System.Drawing.Size(108, 72);
            this.bPose.TabIndex = 10;
            this.bPose.TabStop = false;
            this.bPose.Text = "Pose";
            // 
            // sPose
            // 
            this.sPose.Location = new System.Drawing.Point(7, 20);
            this.sPose.Maximum = 5;
            this.sPose.Name = "sPose";
            this.sPose.Size = new System.Drawing.Size(95, 45);
            this.sPose.TabIndex = 0;
            // 
            // bQuality
            // 
            this.bQuality.Controls.Add(this.sQuality);
            this.bQuality.Location = new System.Drawing.Point(117, 315);
            this.bQuality.Name = "bQuality";
            this.bQuality.Size = new System.Drawing.Size(108, 72);
            this.bQuality.TabIndex = 11;
            this.bQuality.TabStop = false;
            this.bQuality.Text = "Quality";
            // 
            // sQuality
            // 
            this.sQuality.Location = new System.Drawing.Point(7, 20);
            this.sQuality.Maximum = 5;
            this.sQuality.Name = "sQuality";
            this.sQuality.Size = new System.Drawing.Size(95, 45);
            this.sQuality.TabIndex = 0;
            // 
            // bBackground
            // 
            this.bBackground.Controls.Add(this.sBackground);
            this.bBackground.Location = new System.Drawing.Point(3, 393);
            this.bBackground.Name = "bBackground";
            this.bBackground.Size = new System.Drawing.Size(108, 72);
            this.bBackground.TabIndex = 12;
            this.bBackground.TabStop = false;
            this.bBackground.Text = "Background";
            // 
            // sBackground
            // 
            this.sBackground.Location = new System.Drawing.Point(7, 20);
            this.sBackground.Maximum = 5;
            this.sBackground.Name = "sBackground";
            this.sBackground.Size = new System.Drawing.Size(95, 45);
            this.sBackground.TabIndex = 0;
            // 
            // bOther
            // 
            this.bOther.Controls.Add(this.sOther);
            this.bOther.Location = new System.Drawing.Point(117, 393);
            this.bOther.Name = "bOther";
            this.bOther.Size = new System.Drawing.Size(108, 72);
            this.bOther.TabIndex = 13;
            this.bOther.TabStop = false;
            this.bOther.Text = "Other";
            // 
            // sOther
            // 
            this.sOther.Location = new System.Drawing.Point(7, 20);
            this.sOther.Maximum = 5;
            this.sOther.Name = "sOther";
            this.sOther.Size = new System.Drawing.Size(95, 45);
            this.sOther.TabIndex = 0;
            // 
            // bFinish
            // 
            this.bFinish.Location = new System.Drawing.Point(3, 471);
            this.bFinish.Name = "bFinish";
            this.bFinish.Size = new System.Drawing.Size(75, 23);
            this.bFinish.TabIndex = 14;
            this.bFinish.Text = "Finish";
            this.bFinish.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.bUndo);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.tbRating);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 315);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(239, 307);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Rating:";
            // 
            // tbRating
            // 
            this.tbRating.Location = new System.Drawing.Point(47, 7);
            this.tbRating.Name = "tbRating";
            this.tbRating.Size = new System.Drawing.Size(100, 20);
            this.tbRating.TabIndex = 17;
            this.tbRating.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(9, 33);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 18;
            this.button1.Text = "1 - Explicit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(90, 33);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(94, 23);
            this.button2.TabIndex = 19;
            this.button2.Text = "2 - Questionable";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(190, 33);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 20;
            this.button3.Text = "3 - Safe";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1004, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openCollectionToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openCollectionToolStripMenuItem
            // 
            this.openCollectionToolStripMenuItem.Name = "openCollectionToolStripMenuItem";
            this.openCollectionToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.openCollectionToolStripMenuItem.Text = "Open Collection";
            this.openCollectionToolStripMenuItem.Click += new System.EventHandler(this.openCollectionToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.skipToolStripMenuItem,
            this.goToIndexToolStripMenuItem,
            this.toolStripSeparator1,
            this.removeToolStripMenuItem,
            this.deleteToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // skipToolStripMenuItem
            // 
            this.skipToolStripMenuItem.Name = "skipToolStripMenuItem";
            this.skipToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.skipToolStripMenuItem.Text = "Skip";
            this.skipToolStripMenuItem.Click += new System.EventHandler(this.skipToolStripMenuItem_Click);
            // 
            // goToIndexToolStripMenuItem
            // 
            this.goToIndexToolStripMenuItem.Name = "goToIndexToolStripMenuItem";
            this.goToIndexToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.goToIndexToolStripMenuItem.Text = "Go to Index";
            this.goToIndexToolStripMenuItem.Click += new System.EventHandler(this.goToIndexToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(131, 6);
            // 
            // removeToolStripMenuItem
            // 
            this.removeToolStripMenuItem.Name = "removeToolStripMenuItem";
            this.removeToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.removeToolStripMenuItem.Text = "Remove";
            this.removeToolStripMenuItem.Click += new System.EventHandler(this.removeToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lIndex,
            this.lFilename});
            this.statusStrip1.Location = new System.Drawing.Point(0, 631);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1004, 24);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lIndex
            // 
            this.lIndex.Name = "lIndex";
            this.lIndex.Size = new System.Drawing.Size(35, 19);
            this.lIndex.Text = "Index";
            // 
            // lFilename
            // 
            this.lFilename.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.lFilename.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.lFilename.Name = "lFilename";
            this.lFilename.Size = new System.Drawing.Size(43, 19);
            this.lFilename.Text = "Name";
            // 
            // bUndo
            // 
            this.bUndo.Location = new System.Drawing.Point(3, 263);
            this.bUndo.Name = "bUndo";
            this.bUndo.Size = new System.Drawing.Size(75, 23);
            this.bUndo.TabIndex = 21;
            this.bUndo.Text = "Undo";
            this.bUndo.UseVisualStyleBackColor = true;
            this.bUndo.Click += new System.EventHandler(this.bUndo_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 655);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.bFace.ResumeLayout(false);
            this.bFace.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFace)).EndInit();
            this.bHair.ResumeLayout(false);
            this.bHair.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sHair)).EndInit();
            this.bChest.ResumeLayout(false);
            this.bChest.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sChest)).EndInit();
            this.bStomach.ResumeLayout(false);
            this.bStomach.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sStomach)).EndInit();
            this.bPelvis.ResumeLayout(false);
            this.bPelvis.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sPelvis)).EndInit();
            this.bArms.ResumeLayout(false);
            this.bArms.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sArms)).EndInit();
            this.bLegs.ResumeLayout(false);
            this.bLegs.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sLegs)).EndInit();
            this.bClothes.ResumeLayout(false);
            this.bClothes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sClothes)).EndInit();
            this.bPose.ResumeLayout(false);
            this.bPose.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sPose)).EndInit();
            this.bQuality.ResumeLayout(false);
            this.bQuality.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sQuality)).EndInit();
            this.bBackground.ResumeLayout(false);
            this.bBackground.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sBackground)).EndInit();
            this.bOther.ResumeLayout(false);
            this.bOther.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sOther)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openCollectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.ToolStripMenuItem skipToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem goToIndexToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel lFilename;
        private System.Windows.Forms.ToolStripStatusLabel lIndex;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.GroupBox bFace;
        private System.Windows.Forms.TrackBar sFace;
        private System.Windows.Forms.GroupBox bHair;
        private System.Windows.Forms.TrackBar sHair;
        private System.Windows.Forms.GroupBox bChest;
        private System.Windows.Forms.TrackBar sChest;
        private System.Windows.Forms.GroupBox bStomach;
        private System.Windows.Forms.TrackBar sStomach;
        private System.Windows.Forms.GroupBox bPelvis;
        private System.Windows.Forms.TrackBar sPelvis;
        private System.Windows.Forms.GroupBox bArms;
        private System.Windows.Forms.TrackBar sArms;
        private System.Windows.Forms.GroupBox bLegs;
        private System.Windows.Forms.TrackBar sLegs;
        private System.Windows.Forms.GroupBox bClothes;
        private System.Windows.Forms.TrackBar sClothes;
        private System.Windows.Forms.GroupBox bPose;
        private System.Windows.Forms.TrackBar sPose;
        private System.Windows.Forms.GroupBox bQuality;
        private System.Windows.Forms.TrackBar sQuality;
        private System.Windows.Forms.GroupBox bBackground;
        private System.Windows.Forms.TrackBar sBackground;
        private System.Windows.Forms.GroupBox bOther;
        private System.Windows.Forms.TrackBar sOther;
        private System.Windows.Forms.Button bFinish;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbRating;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button bUndo;
    }
}

